
package util;

/**
 *
 * @author hugov
 */
public class Config {
public String email = "projetoimobiliariahv@gmail.com";
public String whatsapp = "(31)97527-5084";
public String telfixo = "(31)3333-3333";
public String whatsappLink = "5531975275084";


//CONFIGURAÇÕES DO BANCO DE DADOS
public String servidor = "localhost";
public String banco = "imobiliaria";
public String usuario = "root";
public String senha = "";
}
